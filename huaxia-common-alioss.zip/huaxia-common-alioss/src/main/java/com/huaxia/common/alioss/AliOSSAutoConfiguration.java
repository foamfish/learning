package com.huaxia.common.alioss;

import com.huaxia.common.alioss.client.OSSClientTemplate;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@EnableConfigurationProperties({AliOSSProperties.class})
public class AliOSSAutoConfiguration {

    private final AliOSSProperties properties;

    public AliOSSAutoConfiguration(AliOSSProperties properties) {
        this.properties = properties;
    }

    @Bean
    @ConditionalOnMissingBean(OSSClientTemplate.class)
    @ConditionalOnProperty(name = "alioss.endpoint")
    OSSClientTemplate clientTemplate() {
        return new OSSClientTemplate(properties);
    }
}
