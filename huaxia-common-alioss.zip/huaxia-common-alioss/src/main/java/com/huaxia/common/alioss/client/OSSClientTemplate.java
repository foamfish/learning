package com.huaxia.common.alioss.client;

import com.aliyun.oss.HttpMethod;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.common.utils.BinaryUtil;
import com.aliyun.oss.event.ProgressEvent;
import com.aliyun.oss.event.ProgressEventType;
import com.aliyun.oss.event.ProgressListener;
import com.aliyun.oss.model.*;
import com.huaxia.common.alioss.AliOSSProperties;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.util.Assert;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

public class OSSClientTemplate implements InitializingBean, DisposableBean {

    private final String endpoint;
    private final String accessKey;
    private final String secretKey;
    private final String callbackUrl;

    private OSS client;

    public OSSClientTemplate(AliOSSProperties properties) {
        this.endpoint = properties.getEndpoint();
        this.accessKey = properties.getAccessKey();
        this.secretKey = properties.getSecretKey();
        this.callbackUrl = "";
    }

    @Override
    public void afterPropertiesSet() {
        Assert.hasText(endpoint, "AliOSS url is null");
        Assert.hasText(accessKey, "AliOSS accessKey is null");
        Assert.hasText(secretKey, "AliOSS secretKey is null");
        client = new OSSClient(endpoint, accessKey, secretKey);
    }

    @Override
    public void destroy() {
        client.shutdown();
    }

    /**
     * 上传字节流.
     *
     * @param bucketName 存储地址
     * @param key        文件名
     * @param stream     流
     * @throws Exception
     */
    public void putObject(String bucketName, String key, InputStream stream) {
        client.putObject(bucketName, key, stream);
        client.setObjectAcl(bucketName, key, CannedAccessControlList.Private);
    }

    /**
     * 上传字符串.
     *
     * @param bucketName 存储地址
     * @param key        文件名
     * @param content    字符串
     * @throws Exception
     */
    public void putObject(String bucketName, String key, String content) {
        client.putObject(bucketName, key, new ByteArrayInputStream(content.getBytes()));
        client.setObjectAcl(bucketName, key, CannedAccessControlList.Private);
    }

    /**
     * 上传文件.
     *
     * @param bucketName 存储地址
     * @param key        文件名
     * @param file       文件
     * @throws Exception
     */
    public void putObject(String bucketName, String key, File file) {
        client.putObject(new PutObjectRequest(bucketName, key, file));
        client.setObjectAcl(bucketName, key, CannedAccessControlList.Private);
    }

    /**
     * 上传文件
     *
     * @param url
     * @param inputStream
     * @param length
     * @param customHeaders
     */
    public void putObject(String url, InputStream inputStream, long length, Map customHeaders) {
        try {
            client.putObject(new URL(url), inputStream, length, customHeaders);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("Url is not valid");
        }
    }

    /**
     * 下载文件.
     *
     * @param bucketName
     * @param key
     * @param pathname
     */
    public void getObject(String bucketName, String key, String pathname) {
        client.getObject(new GetObjectRequest(bucketName, key), new File(pathname));
    }

    /**
     * 签名URL.
     *
     * @param bucketName
     * @param key
     * @return
     */
    public URL generatePresignedUrl(String bucketName, String key) {
        long expireTime = 60;
        long expireEndTime = System.currentTimeMillis() + expireTime * 1000;
        Date expiration = new Date(expireEndTime);
        return client.generatePresignedUrl(bucketName, key, expiration);
    }

    /**
     * upload file URL.
     *
     * @param bucketName
     * @param key
     * @return
     */
    public URL generatePresignedUploadUrl(String bucketName, String key) {
        GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(bucketName, key, HttpMethod.PUT);
        long expireTime = 60;
        long expireEndTime = System.currentTimeMillis() + expireTime * 1000;
        Date expiration = new Date(expireEndTime);
        request.setExpiration(expiration);
        return client.generatePresignedUrl(request);
    }

    /**
     * upload mp4 Url.
     *
     * @param bucketName
     * @param key
     * @return
     */
    public URL generatePresignedUploadUrl(String bucketName, String key, String type) {
        GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(bucketName, key, HttpMethod.PUT);
        long expireTime = 60;
        long expireEndTime = System.currentTimeMillis() + expireTime * 1000;
        Date expiration = new Date(expireEndTime);
        request.setExpiration(expiration);
        request.setContentType("video/mp4");
        return client.generatePresignedUrl(request);
    }

    public Map genratePolicy(String bucketName, String key) {
        String host = "https://" + bucketName + "." + this.endpoint;

        long expireTime = 30;
        long expireEndTime = System.currentTimeMillis() + expireTime * 1000;
        Date expiration = new Date(expireEndTime);

        PolicyConditions policyConds = new PolicyConditions();
        policyConds.addConditionItem(PolicyConditions.COND_CONTENT_LENGTH_RANGE, 0, 1048576000);
        policyConds.addConditionItem(MatchMode.StartWith, PolicyConditions.COND_KEY, key);

        String postPolicy = client.generatePostPolicy(expiration, policyConds);
        byte[] binaryData = new byte[0];
        try {
            binaryData = postPolicy.getBytes("utf-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
        String encodedPolicy = BinaryUtil.toBase64String(binaryData);
        String postSignature = client.calculatePostSignature(postPolicy);
        Map<String, String> respMap = new LinkedHashMap<String, String>();
        respMap.put("accessid", this.accessKey);

        respMap.put("policy", encodedPolicy);
        respMap.put("signature", postSignature);
        respMap.put("dir", key);
        respMap.put("host", host);
        respMap.put("expire", String.valueOf(expiration.getTime() / 1000));

        JSONObject jasonCallback = new JSONObject();
        try {
            jasonCallback.put("callbackUrl", callbackUrl);
            jasonCallback.put("callbackBody",
                    "filename=${object}&size=${size}&mimeType=${mimeType}&height=${imageInfo.height}&width=${imageInfo.width}");
            jasonCallback.put("callbackBodyType", "application/x-www-form-urlencoded");
            String base64CallbackBody = BinaryUtil.toBase64String(jasonCallback.toString().getBytes());
            respMap.put("callback", base64CallbackBody);

//            JSONObject ja1 = new JSONObject(respMap);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return respMap;
    }

    private GeneratePresignedUrlRequest generatePresignedUrlRequest(String bucketName, String key, HttpMethod httpMethod) {
        Date expiration = new Date(new Date().getTime() + 3600 * 1000);
        GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(bucketName, key, httpMethod);
        request.setExpiration(expiration);
        return request;
    }

    /**
     * 判断文件是否存在.
     *
     * @param bucketName
     * @param key
     * @return
     */
    private boolean isExist(String bucketName, String key) {
        return client.doesObjectExist(bucketName, key);
    }

    // TODO upload file with progress
    static class PutObjectProgressListener implements ProgressListener {

        private long bytesWritten = 0;
        private long totalBytes = -1;
        private boolean succeed = false;

        @Override
        public void progressChanged(ProgressEvent progressEvent) {
            long bytes = progressEvent.getBytes();
            ProgressEventType eventType = progressEvent.getEventType();
            switch (eventType) {
                case TRANSFER_STARTED_EVENT:
                    System.out.println("Start to upload......");
                    break;

                case REQUEST_CONTENT_LENGTH_EVENT:
                    this.totalBytes = bytes;
                    System.out.println(this.totalBytes + " bytes in total will be uploaded to OSS");
                    break;

                case REQUEST_BYTE_TRANSFER_EVENT:
                    this.bytesWritten += bytes;
                    if (this.totalBytes != -1) {
                        int percent = (int) (this.bytesWritten * 100.0 / this.totalBytes);
                        System.out.println(bytes + " bytes have been written at this time, upload progress: " +
                                percent + "%(" + this.bytesWritten + "/" + this.totalBytes + ")");
                    } else {
                        System.out.println(bytes + " bytes have been written at this time, upload ratio: unknown" +
                                "(" + this.bytesWritten + "/...)");
                    }
                    break;

                case TRANSFER_COMPLETED_EVENT:
                    this.succeed = true;
                    System.out.println("Succeed to upload, " + this.bytesWritten + " bytes have been transferred in total");
                    break;

                case TRANSFER_FAILED_EVENT:
                    System.out.println("Failed to upload, " + this.bytesWritten + " bytes have been transferred");
                    break;

                default:
                    break;
            }
        }

        public boolean isSucceed() {
            return succeed;
        }
    }


}
