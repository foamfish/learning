package com.huaxia.common.alioss.web;


import com.aliyun.oss.common.utils.BinaryUtil;
import com.huaxia.common.alioss.client.OSSClientTemplate;
import com.huaxia.common.alioss.vo.OSSObject;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.URI;
import java.net.URL;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/alioss")
@ConditionalOnProperty(name = "alioss.endpoint.enabled", havingValue = "true")
public class AliOSSEndpoint {

    private final OSSClientTemplate template;

    @Autowired
    public AliOSSEndpoint(OSSClientTemplate template) {
        this.template = template;
    }

    /**
     * upload content.
     */
    @PostMapping("/upload")
    public void upload(@RequestBody OSSObject ossObject) {
        template.putObject(ossObject.getBucketName(), ossObject.getKey(), ossObject.getContent());
    }

    /**
     * upload File.
     *
     * @param bucketName
     * @param key
     * @param file
     * @return
     */
    @PostMapping("/uploadFile")
    public void uploadFile(@RequestParam("bucketName") String bucketName, @RequestParam("key") String key, @RequestParam("file") MultipartFile file) {
        try (InputStream inputStream = file.getInputStream()) {
            template.putObject(bucketName, key, inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @GetMapping("/getDownloadUrl")
    public URL getDownloadUrl(@RequestParam("bucketName") String bucketName, @RequestParam("key") String key) {
        return template.generatePresignedUrl(bucketName, key);
    }

    @GetMapping("/getUploadUrl")
    public URL getUploadUrl(@RequestParam("bucketName") String bucketName, @RequestParam("key") String key) {
        return template.generatePresignedUploadUrl(bucketName, key);
    }

    @GetMapping("/genratePolicy")
    public Map genratePolicy(@RequestParam("bucketName") String bucketName, @RequestParam("key") String key) {
        return template.genratePolicy(bucketName, key);
    }

    @PostMapping("/callback")
    public Boolean callback(HttpServletRequest request, @RequestBody String requestBody,
                        @RequestHeader(value = "Authorization") String authorization,
                        @RequestHeader(value = "x-oss-pub-key-url") String pubKeyUrl) {
        boolean ret = false;
        byte[] autorizationInput = BinaryUtil.fromBase64String(authorization);
        byte[] pubKey = BinaryUtil.fromBase64String(pubKeyUrl);
        String pubKeyAddr = new String(pubKey);
        if (!pubKeyAddr.startsWith("http://gosspublic.alicdn.com/")
                && !pubKeyAddr.startsWith("https://gosspublic.alicdn.com/")) {
            System.out.println("pub key addr must be oss addrss");
            return false;
        }
        String retString = executeGet(pubKeyAddr);
        retString = retString.replace("-----BEGIN PUBLIC KEY-----", "");
        retString = retString.replace("-----END PUBLIC KEY-----", "");
        String queryString = request.getQueryString();
        String uri = request.getRequestURI();
        String decodeUri = null;
        try {
            decodeUri = java.net.URLDecoder.decode(uri, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String authStr = decodeUri;
        if (queryString != null && !queryString.equals("")) {
            authStr += "?" + queryString;
        }
        authStr += "\n" + requestBody;
        ret = doCheck(authStr, autorizationInput, retString);
        return ret;
    }

    /**
     * 获取public key
     *
     * @param url
     * @return
     */
    private String executeGet(String url) {
        BufferedReader in = null;
        String content = null;
        try {
            // 定义HttpClient
            DefaultHttpClient client = new DefaultHttpClient();
            // 实例化HTTP方法
            HttpGet request = new HttpGet();
            request.setURI(new URI(url));
            HttpResponse response = client.execute(request);

            in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            StringBuffer sb = new StringBuffer("");
            String line = "";
            String NL = System.getProperty("line.separator");
            while ((line = in.readLine()) != null) {
                sb.append(line + NL);
            }
            in.close();
            content = sb.toString();
        } catch (Exception e) {
        } finally {
            if (in != null) {
                try {
                    in.close();// 最后要关闭BufferedReader
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return content;
        }
    }

    /**
     * 验证RSA
     *
     * @param content
     * @param sign
     * @param publicKey
     * @return
     */
    private static boolean doCheck(String content, byte[] sign, String publicKey) {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = BinaryUtil.fromBase64String(publicKey);
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));
            java.security.Signature signature = java.security.Signature.getInstance("MD5withRSA");
            signature.initVerify(pubKey);
            signature.update(content.getBytes());
            boolean bverify = signature.verify(sign);
            return bverify;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    /**
     * upload File.
     *
     * @param url
     * @param file
     * @return
     */
    @PostMapping("/uploadWithPresignedUploadUrl")
    public void uploadWithPresignedUploadUrl(@RequestParam("url") String url, @RequestParam("file") MultipartFile file) {
        try (InputStream inputStream = file.getInputStream()) {
            Map<String, String> customHeaders = new HashMap<>();
            customHeaders.put("Content-Type", file.getContentType());
            template.putObject(url, inputStream, file.getSize(), customHeaders);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
