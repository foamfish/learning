package com.huaxia.common.alioss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AliOSSApplication {
    public static void main(String[] args) {
        SpringApplication.run(AliOSSApplication.class, args);
    }
}
